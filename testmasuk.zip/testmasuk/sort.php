<?php
session_start();

require_once "connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menerima data yang dikirimkan melalui Ajax
    $column = $_POST['column'];
    $direction = $_POST['direction'];
    $columnName = $_POST['columnName'];

    // Query untuk mengurutkan data berdasarkan kolom dan arah pengurutan yang diberikan
    $orderByClause = "";
    if ($columnName === "Tanggal Lahir") {
        // Jika kolom adalah TanggalLahir, gunakan STR_TO_DATE() untuk mengonversi string menjadi tanggal
        $orderByClause = "ORDER BY CAST(TanggalLahir AS DATE) $direction";
    }
    elseif ($columnName === "Nomor Telepon") {
        // Jika kolom adalah TanggalLahir, gunakan STR_TO_DATE() untuk mengonversi string menjadi tanggal
        $orderByClause = "ORDER BY NomorTlp $direction";
    }
    elseif($columnName === "Action"){
        
    }
    else {
        // Untuk kolom selain TanggalLahir, langsung gunakan ORDER BY
        $orderByClause = "ORDER BY $columnName $direction";
    }

    $query = "SELECT * FROM mahasiswa WHERE idAdmin = :idAdmin $orderByClause";
    $stmt = $koneksi->prepare($query);
    $stmt->bindValue(':idAdmin', $_GET['idAdmin'], PDO::PARAM_INT);
    $stmt->execute();
    $mahasiswa = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Generate kembali isi tbody dengan data yang diurutkan
    foreach ($mahasiswa as $mhs) {
        echo "<tr>";
        echo "<td>" . $mhs['Nim'] . "</td>";
        echo "<td>" . $mhs['Nama'] . "</td>";
        echo "<td>" . $mhs['TanggalLahir'] . "</td>";
        echo "<td>" . $mhs['Alamat'] . "</td>";
        echo "<td><img src='images/" . $mhs['Foto'] . "' alt='Foto Mahasiswa' width='30' height='30'></td>";
        echo "<td>" . $mhs['NomorTlp'] . "</td>";
        echo "<td><a href='edit.php?id=" . $mhs['id'] . "&idAdmin=" . $_GET['idAdmin'] . "'>Edit</a> | <a href='delete.php?id=" . $mhs['id'] . "&idAdmin=" . $_GET['idAdmin'] . "' onclick=\"return confirm('Apakah Anda yakin ingin menghapus data ini?');\">Delete</a></td>";
        echo "</tr>";
    }
}
?>
