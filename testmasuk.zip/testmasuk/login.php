<?php
session_start();

require_once "connection.php";

// Pastikan koneksi ke database berhasil
if (!$koneksi) {
    // Tangani kesalahan jika koneksi gagal
    echo "Koneksi ke database gagal!";
    exit(); // Hentikan eksekusi skrip
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mendapatkan nilai username dan password dari form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mendapatkan data admin berdasarkan username
    $stmt = $koneksi->prepare("SELECT * FROM admin WHERE username=:username");
    $stmt->execute(['username' => $username]);
    $admin = $stmt->fetch();

    if ($admin) {
        // Memeriksa apakah password cocok
        if ($password === $admin['password']) { // Membandingkan password tanpa hash
            // Set session sebagai tanda bahwa admin sudah login
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['idAdmin'] = $admin['id']; // Set session idAdmin
            // Redirect ke halaman admin setelah login berhasil
            header("Location: listmahasiswa.php?idAdmin={$admin['id']}");
            exit();
        } else {
            // Jika password salah, tampilkan pesan error
            $login_error = "Password salah!";
        }
    } else {
        // Jika username belum terdaftar, masukkan data ke dalam tabel admin
        $insert_stmt = $koneksi->prepare("INSERT INTO admin (username, password) VALUES (:username, :password)");
        $insert_stmt->execute(['username' => $username, 'password' => $password]); // Menyimpan password tanpa hash
        
        // Set session sebagai tanda bahwa admin sudah login
        $_SESSION['admin_logged_in'] = true;
        
        // Ambil idAdmin yang baru saja di-generate
        $newIdAdmin = $koneksi->lastInsertId();
        
        // Set session idAdmin
        $_SESSION['idAdmin'] = $newIdAdmin;
        
        // Redirect ke halaman admin setelah login berhasil
        header("Location: listmahasiswa.php?idAdmin={$newIdAdmin}");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
</head>
<body>
    <h2>Admin Login</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username"><br>
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password"><br><br>
        <input type="submit" value="Login">
    </form>
    <?php if(isset($login_error)) echo "<p>$login_error</p>"; ?>
</body>
</html>
