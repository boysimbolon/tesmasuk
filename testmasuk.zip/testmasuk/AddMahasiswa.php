<?php
session_start();
require_once "connection.php";
// Mengambil ID admin dari sesi
$idAdmin = $_SESSION['idAdmin'];

// Proses form jika disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mendapatkan nilai dari form
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];
    $nomor_telepon = $_POST['nomor_telepon'];
    $foto_nama = $_FILES['foto']['name'];
    $foto_tmp_name = $_FILES['foto']['tmp_name'];

    if ($koneksi) {
        try {
            // Persiapan query untuk menyimpan data mahasiswa ke database
            $stmt = $koneksi->prepare("INSERT INTO mahasiswa (idAdmin, Nim, Nama, TanggalLahir, Alamat, Foto, NomorTlp) VALUES (:idAdmin, :nim, :nama, :tanggal_lahir, :alamat, :foto, :nomor_telepon)");

            // Bind parameter ke query
            $stmt->bindParam(':idAdmin', $idAdmin);
            $stmt->bindParam(':nim', $nim);
            $stmt->bindParam(':nama', $nama);
            $stmt->bindParam(':tanggal_lahir', $tanggal_lahir);
            $stmt->bindParam(':alamat', $alamat);
            $stmt->bindParam(':foto', $foto_nama);
            $stmt->bindParam(':nomor_telepon', $nomor_telepon);

            // Pindahkan file foto ke folder 'images'
            move_uploaded_file($foto_tmp_name, "images/$foto_nama");

            // Eksekusi query
            $stmt->execute();
            echo "Data mahasiswa berhasil disimpan!";
            header("Location: listmahasiswa.php?idAdmin=$idAdmin");
        } catch(PDOException $e) {
            // Tangani kesalahan jika query gagal
            echo "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Input Mahasiswa</title>
</head>
<body>
    <h2>Form Input Mahasiswa</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <label for="nim">NIM:</label><br>
        <input type="text" id="nim" name="nim"><br>
        <label for="nama">Nama:</label><br>
        <input type="text" id="nama" name="nama"><br>
        <label for="tanggal_lahir">Tanggal Lahir:</label><br>
        <input type="date" id="tanggal_lahir" name="tanggal_lahir"><br>
        <label for="alamat">Alamat:</label><br>
        <textarea id="alamat" name="alamat"></textarea><br>
        <label for="foto">Foto:</label><br>
        <input type="file" id="foto" name="foto" accept="image/*"><br>
        <label for="nomor_telepon">Nomor Telepon:</label><br>
        <input type="text" id="nomor_telepon" name="nomor_telepon"><br><br>
        <input type="submit" value="Simpan">
    </form>
</body>
</html>
