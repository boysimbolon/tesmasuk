<?php
session_start();
require_once "connection.php";
// Memeriksa apakah admin sudah login
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Jika belum, redirect ke halaman login
    header("Location: login.php");
    exit();
}

// Memeriksa apakah parameter id tersedia dalam URL
if (!isset($_GET['id'])) {
    // Jika tidak, redirect ke halaman utama
    header("Location: index.php");
    exit();
}

// Mengambil ID admin dari sesi
$idAdmin = $_GET['idAdmin'];
$idMahasiswa = $_GET['id'];

// Menghapus data mahasiswa berdasarkan ID admin dan ID mahasiswa
if ($koneksi) {
    try {
        // Query untuk menghapus data mahasiswa berdasarkan ID admin dan ID mahasiswa
        $stmt = $koneksi->prepare("DELETE FROM mahasiswa WHERE idAdmin = :idAdmin AND id = :idMahasiswa");
        $stmt->execute(['idAdmin' => $idAdmin, 'idMahasiswa' => $idMahasiswa]);
        // Redirect ke halaman utama setelah penghapusan berhasil
        header("Location: listmahasiswa.php?idAdmin=$idAdmin");
        exit();
    } catch(PDOException $e) {
        // Tangani kesalahan jika query gagal
        echo "Error: " . $e->getMessage();
        exit();
    }
}
?>
