<?php
$host = 'localhost'; 
$dbname = 'testmasuk';
$username = 'root'; 
$password = ''; 

try {
    // Buat koneksi menggunakan PDO
    $koneksi = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Atur mode error untuk PDO ke Exception
    $koneksi->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch(PDOException $e) {
    // Tangani kesalahan jika koneksi gagal
   
}
?>
