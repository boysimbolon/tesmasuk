<?php
// Mendapatkan idAdmin dari parameter GET
$idAdmin = isset($_GET['idAdmin']) ? $_GET['idAdmin'] : '';

// Memeriksa apakah format yang diminta adalah excel
if (isset($_GET['format']) && $_GET['format'] === 'excel') {
    exportToExcel($idAdmin);
} elseif (isset($_GET['format']) && $_GET['format'] === 'pdf') {
    exportToPDF($idAdmin);
}

// Fungsi untuk mengekspor data ke Excel
function exportToExcel($idAdmin) {
    require_once "connection.php";
    // Mendapatkan filter NIM dan Nama dari parameter GET
    $filterNIM = isset($_GET['filter_nim']) ? $_GET['filter_nim'] : '';
    $filterNama = isset($_GET['filter_nama']) ? $_GET['filter_nama'] : '';
    
    if ($koneksi) {
        try {
            // Query untuk mendapatkan data mahasiswa berdasarkan filter
            $query = "SELECT * FROM mahasiswa WHERE idAdmin = :idAdmin";
            if (!empty($filterNIM)) {
                $query .= " AND NIM LIKE '%$filterNIM%'";
            }
            if (!empty($filterNama)) {
                $query .= " AND Nama LIKE '%$filterNama%'";
            }
            $stmt = $koneksi->prepare($query);
            $stmt->execute(['idAdmin' => $idAdmin]);
            $mahasiswa = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Mengatur header untuk file Excel
            header("Content-type: application/vnd-ms-excel");
            header("Content-Disposition: attachment; filename=Data_Mahasiswa.xls");

            // Mulai penulisan data Excel
            echo '<table border="1">'; // Mulai tabel
            echo '<tr><th>NIM</th><th>Nama</th><th>Tanggal Lahir</th><th>Alamat</th><th>Foto</th><th>Nomor Telepon</th></tr>'; // Baris header
            foreach ($mahasiswa as $mhs) {
                echo '<tr>'; // Baris data
                echo '<td>' . $mhs['Nim'] . '</td>'; // Kolom NIM
                echo '<td>' . $mhs['Nama'] . '</td>'; // Kolom Nama
                echo '<td>' . $mhs['TanggalLahir'] . '</td>'; // Kolom Tanggal Lahir
                echo '<td>' . $mhs['Alamat'] . '</td>'; // Kolom Alamat
               echo '<td><img src="http://localhost/testmasuk/images/' . $mhs['Foto'] . '" height="20" width="20"></td>'; // Kolom Foto
                echo '<td>' . $mhs['NomorTlp'] . '</td>'; // Kolom Nomor Telepon
                echo '</tr>'; // Akhiri baris data
            }
            echo '</table>'; // Selesai tabel

            exit(); // Keluar dari skrip setelah menulis data Excel
        } catch(PDOException $e) {
            // Tangani kesalahan jika query gagal
            echo "Error: " . $e->getMessage();
            exit();
        }
    }
}
function exportToPDF($idAdmin) {
    require_once "connection.php";
    
    // Mendapatkan filter NIM dan Nama dari parameter GET
    $filterNIM = isset($_GET['filter_nim']) ? $_GET['filter_nim'] : '';
    $filterNama = isset($_GET['filter_nama']) ? $_GET['filter_nama'] : '';
    
    if ($koneksi) {
        try {
            // Query untuk mendapatkan data mahasiswa berdasarkan filter
            $query = "SELECT * FROM mahasiswa WHERE idAdmin = :idAdmin";
            if (!empty($filterNIM)) {
                $query .= " AND NIM LIKE '%$filterNIM%'";
            }
            if (!empty($filterNama)) {
                $query .= " AND Nama LIKE '%$filterNama%'";
            }
            $stmt = $koneksi->prepare($query);
            $stmt->execute(['idAdmin' => $idAdmin]);
            $mahasiswa = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Membuat objek FPDF
            require('fpdf186/fpdf.php');
            $pdf = new FPDF();
            $pdf->AddPage();

            // Judul tabel
            $pdf->SetFont('Arial', 'B', 16);
            $pdf->Cell(190, 10, 'Data Mahasiswa', 0, 1, 'C');

            // Header tabel
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(20, 10, 'NIM', 1);
            $pdf->Cell(40, 10, 'Nama', 1);
            $pdf->Cell(40, 10, 'Tanggal Lahir', 1);
            $pdf->Cell(40, 10, 'Alamat', 1);
            $pdf->Cell(35, 10, 'Nomor Telepon', 1);
            $pdf->Cell(30, 10, 'Foto', 1);
            $pdf->Ln();

            // Isi tabel
            foreach ($mahasiswa as $mhs) {
                $pdf->Cell(20, 10, $mhs['Nim'], 1);
                $pdf->Cell(40, 10, $mhs['Nama'], 1);
                $pdf->Cell(40, 10, $mhs['TanggalLahir'], 1);
                $pdf->Cell(40, 10, $mhs['Alamat'], 1); // Gunakan MultiCell untuk wrap konten
                $pdf->Cell(35, 10, $mhs['NomorTlp'], 1);
                
                // Menampilkan gambar
if (!empty($mhs['Foto'])) {
    // Membuat path lengkap ke gambar
    $gambarPath = 'images/' . $mhs['Foto'];
    // Memeriksa apakah file gambar ada
    if (file_exists($gambarPath)) {
        // Jika ada, tambahkan gambar ke PDF dengan ukuran 30x30
        $pdf->Cell(30, 10, $pdf->Image($gambarPath, $pdf->GetX(), $pdf->GetY(), 10), 1); // Menggunakan Cell dengan ukuran 30x30
    } else {
        // Jika tidak, biarkan sel kosong
        $pdf->Cell(30, 30, '', 1);
    }
} else {
    // Jika field 'Foto' kosong, biarkan sel kosong
    $pdf->Cell(30, 30, '', 1);
}
                $pdf->Ln(); // Pindah ke baris berikutnya
            }

            // Output file PDF
            $pdf->Output();
            exit();
        } catch(PDOException $e) {
            // Tangani kesalahan jika query gagal
            echo "Error: " . $e->getMessage();
            exit();
        }
    }
}



?>
