<?php
session_start();

require_once "connection.php";

// Memeriksa apakah admin sudah login
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Jika belum, redirect ke halaman login
    header("Location: login.php");
    exit();
}

// Mengambil ID admin dari sesi
$idAdmin = $_GET['idAdmin'];

// Inisialisasi variabel filter
$filterNIM = "";
$filterNama = "";

// Memeriksa apakah filter NIM atau Nama diset
if (isset($_GET['filter_nim'])) {
    $filterNIM = $_GET['filter_nim'];
}

if (isset($_GET['filter_nama'])) {
    $filterNama = $_GET['filter_nama'];
}

// Mengambil data mahasiswa berdasarkan ID admin dan filter (jika ada)
if ($koneksi) {
    try {
        // Query untuk mendapatkan data mahasiswa berdasarkan ID admin dan filter (jika ada)
        $query = "SELECT * FROM mahasiswa WHERE idAdmin = :idAdmin";
        // Tambahkan filter NIM jika diset
        if (!empty($filterNIM)) {
            $query .= " AND NIM LIKE '%$filterNIM%'";
        }
        // Tambahkan filter Nama jika diset
        if (!empty($filterNama)) {
            $query .= " AND Nama LIKE '%$filterNama%'";
        }
        $stmt = $koneksi->prepare($query);
        $stmt->execute(['idAdmin' => $idAdmin]);
        $mahasiswa = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        // Tangani kesalahan jika query gagal
        echo "Error: " . $e->getMessage();
        $mahasiswa = [];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Mahasiswa</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            cursor: pointer;
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("th").click(function(){
                var column = $(this).index(); // Mendapatkan indeks kolom header yang diklik
                var direction = $(this).hasClass("asc") ? "desc" : "asc"; // Mendapatkan arah pengurutan (asc/desc)
                var columnName = $(this).text(); // Mendapatkan nama kolom yang diklik
                $.ajax({
                    url: "sort.php?idAdmin=<?php echo $idAdmin; ?>", // File PHP untuk pengurutan
                    type: "POST",
                    data: {column: column, direction: direction, columnName: columnName}, // Mengirim data ke server
                    success: function(data){
                        $("tbody").html(data); // Mengganti konten tbody dengan hasil pengurutan
                        $("th").removeClass("asc desc"); // Menghapus kelas asc dan desc dari semua th
                        $("th").eq(column).addClass(direction); // Menambahkan kelas asc atau desc pada th yang sesuai
                    }
                });
            });
        });
    </script>
</head>
<body>
    <h2>Data Mahasiswa</h2>
    <a href="AddMahasiswa.php?idAdmin=<?php echo $idAdmin ?>">Tambah Mahasiswa</a>
    <form action="listmahasiswa.php?idAdmin=<?php echo $idAdmin; ?>" method="get">
        <label for="filter_nim">Filter NIM:</label>
        <input type="text" id="filter_nim" name="filter_nim" value="<?php echo $filterNIM; ?>">
        <label for="filter_nama">Filter Nama:</label>
        <input type="text" id="filter_nama" name="filter_nama" value="<?php echo $filterNama; ?>">
        <input type="hidden" id="idAdmin" name="idAdmin" value="<?php echo $idAdmin; ?>">
        <button type="submit">Filter</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>NIM</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>Foto</th>
                <th>Nomor Telepon</th>
                <th>Action</th>
            </tr>
        </thead>
    <tbody>
    <?php
    // Iterasi dan menampilkan data mahasiswa
    foreach ($mahasiswa as $mhs) {
        echo "<tr>";
        echo "<td>" . $mhs['Nim'] . "</td>";
        echo "<td>" . $mhs['Nama'] . "</td>";
        echo "<td>" . $mhs['TanggalLahir'] . "</td>";
        echo "<td>" . $mhs['Alamat'] . "</td>";
        echo "<td><img src='images/" . $mhs['Foto'] . "' alt='Foto Mahasiswa' width='30' height='30'></td>";
        echo "<td>" . $mhs['NomorTlp'] . "</td>";
        // Tautan action untuk edit dan delete
            echo "<td><a href='edit.php?id=" . $mhs['id'] . "&idAdmin=" . $idAdmin . "'>Edit</a> | <a href='delete.php?id=" . $mhs['id'] . "&idAdmin=" . $idAdmin . "' onclick=\"return confirm('Apakah Anda yakin ingin menghapus data ini?');\">Delete</a></td>";
          echo "</tr>";
    }
    ?>
</tbody>

    </table>
    <br>
<a href="export.php?format=excel&filter_nim=<?php echo $filterNIM; ?>&filter_nama=<?php echo $filterNama; ?>&idAdmin=<?php echo $idAdmin; ?>">Export to Excel</a>

<a href="export.php?format=pdf&filter_nim=<?php echo $filterNIM; ?>&filter_nama=<?php echo $filterNama; ?>&idAdmin=<?php echo $idAdmin; ?>">Export to PDF</a>

</body>
</html>

