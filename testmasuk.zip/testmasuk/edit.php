<?php
session_start();

require_once "connection.php";

// Memeriksa apakah admin sudah login
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Jika belum, redirect ke halaman login
    header("Location: login.php");
    exit();
}

// Memeriksa apakah parameter id tersedia dalam URL
if (!isset($_GET['id']) || !isset($_GET['idAdmin'])) {
    // Jika tidak, redirect ke halaman utama
    header("Location: index.php");
    exit();
}

// Mengambil ID admin dan ID mahasiswa dari URL
$idAdmin = $_GET['idAdmin'];
$idMahasiswa = $_GET['id'];

// Mengambil data mahasiswa berdasarkan ID admin dan ID mahasiswa
if ($koneksi) {
    try {
        // Query untuk mendapatkan data mahasiswa berdasarkan ID admin dan ID mahasiswa
        $stmt = $koneksi->prepare("SELECT * FROM mahasiswa WHERE idAdmin = :idAdmin AND id = :idMahasiswa");
        $stmt->execute(['idAdmin' => $idAdmin, 'idMahasiswa' => $idMahasiswa]);
        $mahasiswa = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Memeriksa apakah data mahasiswa ditemukan
        if (!$mahasiswa) {
            // Jika tidak ditemukan, redirect ke halaman utama
            header("Location: index.php");
            exit();
        }
    } catch(PDOException $e) {
        // Tangani kesalahan jika query gagal
        echo "Error: " . $e->getMessage();
        exit();
    }
}

// Proses form jika disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $tanggalLahir = $_POST['tanggal_lahir'];
    $alamat = $_POST['alamat'];
    $nomorTlp = $_POST['nomor_tlp'];
    $foto_nama = $_FILES['foto']['name'];
    $foto_tmp_name = $_FILES['foto']['tmp_name'];
    
    // Pindahkan file foto ke folder 'images'
    move_uploaded_file($foto_tmp_name, "images/$foto_nama");

    // Proses update data mahasiswa
    try {
        $stmt = $koneksi->prepare("UPDATE mahasiswa SET NIM = :nim, Nama = :nama, TanggalLahir = :tanggalLahir, Alamat = :alamat, NomorTlp = :nomorTlp, Foto = :foto WHERE id = :idMahasiswa");
        $stmt->execute(['nim' => $nim, 'nama' => $nama, 'tanggalLahir' => $tanggalLahir, 'alamat' => $alamat, 'nomorTlp' => $nomorTlp, 'foto' => $foto_nama, 'idMahasiswa' => $idMahasiswa]);
        // Redirect ke halaman utama setelah update berhasil
        header("Location: listmahasiswa.php?idAdmin=$idAdmin");
        exit();
    } catch(PDOException $e) {
        // Tangani kesalahan jika query gagal
        echo "Error: " . $e->getMessage();
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Mahasiswa</title>
</head>
<body>
    <h2>Edit Mahasiswa</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=" . $idMahasiswa . "&idAdmin=" . $idAdmin; ?>" method="post" enctype="multipart/form-data">
        <label for="nim">NIM:</label>
        <input type="text" id="nim" name="nim" value="<?php echo $mahasiswa['Nim']; ?>"><br>
        <label for="nama">Nama:</label>
        <input type="text" id="nama" name="nama" value="<?php echo $mahasiswa['Nama']; ?>"><br>
        <label for="tanggal_lahir">Tanggal Lahir:</label>
        <input type="date" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo $mahasiswa['TanggalLahir']; ?>"><br>
        <label for="alamat">Alamat:</label>
        <input type="text" id="alamat" name="alamat" value="<?php echo $mahasiswa['Alamat']; ?>"><br>
        <label for="nomor_tlp">Nomor Telepon:</label>
        <input type="text" id="nomor_tlp" name="nomor_tlp" value="<?php echo $mahasiswa['NomorTlp']; ?>"><br>
        <label for="foto">Foto:</label>
        <input type="file" id="foto" name="foto"><br><br>
        <button type="submit">Simpan</button>
    </form>
</body>
</html>
